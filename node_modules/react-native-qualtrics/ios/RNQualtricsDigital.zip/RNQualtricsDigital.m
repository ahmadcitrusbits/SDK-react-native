
#import "RNQualtricsDigital.h"

@implementation RNQualtricsDigital

TargetingResult* gTargetingResult;
InitializationResult* gInitializationResult;
NSString *INITIALIZE_EVENT = @"initializeEvent";
NSString *EVALUATE_EVENT = @"evaluateEvent";
NSString *INITIALIZE_PROJECT_EVENT = @"initializeProjectEvent";
NSString *EVALUATE_PROJECT_EVENT = @"evaluateProjectEvent";
NSString *EVALUATE_INTERCEPT_EVENT = @"evaluateInterceptEvent";

- (dispatch_queue_t)methodQueue
{
    return dispatch_get_main_queue();
}

RCT_EXPORT_MODULE()

RCT_EXPORT_METHOD(initializeProject:(NSString* )brandId zoneId:(NSString* )zoneId extRefId:(NSString* _Nullable)extRefId)
{
    NSMutableDictionary<NSString *, NSDictionary *> *initializationResults = [[NSMutableDictionary alloc]init];
    [Qualtrics.shared initializeProjectWithBrandId:brandId projectId:zoneId extRefId:extRefId completion:^(NSDictionary<NSString *,InitializationResult *> * _Nonnull result) {
        for(id key in result) {
            InitializationResult *initializationResult = result[key];
            NSDictionary *initializeResult = [NSDictionary dictionary];
            if (initializationResult.getMessage == nil) {
                continue;
            }

            initializeResult = @{
                @"passed": @(initializationResult.passed),
                @"message": initializationResult.getMessage,
            };

            initializationResults[key] = initializeResult;
        }

        [self sendEventWithName:INITIALIZE_PROJECT_EVENT body:initializationResults];
    }];
}

RCT_EXPORT_METHOD(initialize:(NSString* )brandId zoneId:(NSString* )zoneId interceptId:(NSString* )interceptId)
{
    [Qualtrics.shared initializeWithBrandId:brandId zoneId:zoneId interceptId:interceptId completion:nil];
}

RCT_EXPORT_METHOD(initializeWithCompletion:(NSString* )brandId zoneId:(NSString* )zoneId interceptId:(NSString* )interceptId)
{
    [Qualtrics.shared initializeWithBrandId:brandId zoneId:zoneId interceptId:interceptId completion:^(InitializationResult * _Nonnull initializationResult) {
        
        NSDictionary *initializeResult = [NSNull null];
        if (initializeResult != nil ) {
            gInitializationResult = initializationResult;
            initializeResult = @{
                @"passed": @(initializationResult.passed),
                @"message": initializationResult.getMessage,
            };
        }
        [self sendEventWithName:INITIALIZE_EVENT body:initializeResult];
    }];
}

RCT_EXPORT_METHOD(evaluateProject)
{
    NSMutableDictionary<NSString *, NSDictionary *> *targetingResults = [[NSMutableDictionary alloc]init];
    [Qualtrics.shared evaluateProjectWithCompletion:^(NSDictionary<NSString *,TargetingResult *> * _Nonnull result) {
        if (result != nil) {
            for(id key in result) {
                TargetingResult *targetingResult = result[key];
                NSDictionary *targetResult = [NSDictionary dictionary];

                NSString* surveyURL = surveyURL = targetingResult.getSurveyUrl;
                if(surveyURL == nil) {
                    surveyURL = [NSNull null];
                }
                
                NSString* creativeType = targetingResult.getCreativeType == nil ? [NSNull null] : targetingResult.getCreativeType;
                targetResult = @{
                    @"passed": @(targetingResult.passed),
                    @"surveyUrl": surveyURL,
                    @"creativeType": creativeType,
                };

                targetingResults[key] = targetResult;
            }

            [self sendEventWithName:EVALUATE_PROJECT_EVENT body:targetingResults];
        }
    }];
}

RCT_EXPORT_METHOD(evaluateIntercept:(NSString* )interceptId)
{
    __block NSDictionary *targetResult = [NSNull null];
    [Qualtrics.shared evaluateInterceptFor:interceptId completion:^(TargetingResult * _Nonnull targetingResult) {
        if (targetingResult != nil) {
            gTargetingResult = targetingResult;
            NSString* surveyURL = surveyURL = targetingResult.getSurveyUrl;
            if(surveyURL == nil) {
                surveyURL = [NSNull null];
            }
            
            NSString* creativeType = targetingResult.getCreativeType == nil ? [NSNull null] : targetingResult.getCreativeType;
            targetResult = @{
                @"passed": @(targetingResult.passed),
                @"surveyUrl": surveyURL,
                @"creativeType": creativeType,
            };
        }
        [self sendEventWithName:EVALUATE_INTERCEPT_EVENT body:targetResult];
    }];
}

RCT_EXPORT_METHOD(evaluateTargetingLogic)
{
    __block NSDictionary *targetResult = [NSNull null];
    BOOL initializeFailed = gInitializationResult != nil && !gInitializationResult.passed;
    if (initializeFailed) {
        targetResult = @{
            @"passed": @(gInitializationResult.passed), 
            @"surveyUrl": [NSNull null],
        };
        [self sendEventWithName:EVALUATE_EVENT body:targetResult];
        return;
    }

    [Qualtrics.shared evaluateTargetingLogicWithCompletion:^(TargetingResult * _Nonnull targetingResult) {
        if (targetingResult != nil) {
            gTargetingResult = targetingResult;
            NSString* surveyURL = surveyURL = targetingResult.getSurveyUrl;
            if(surveyURL == nil) {
                surveyURL = [NSNull null];
            } 
            targetResult = @{
                @"passed": @(targetingResult.passed), 
                @"surveyUrl": surveyURL,
            };
        }
        [self sendEventWithName:EVALUATE_EVENT body:targetResult];
    }];
}

RCT_EXPORT_METHOD(display:(RCTResponseSenderBlock)callback)
{
    BOOL initializeFailed = gInitializationResult != nil && !gInitializationResult.passed;
    if (initializeFailed) {
        callback(@[@(false)]);
        return;
    }

    UIViewController *rootViewController = [UIApplication sharedApplication].delegate.window.rootViewController;

    if (rootViewController == nil) {
        UIWindow *rootWindow = nil;
        NSArray *windows = [[UIApplication sharedApplication]windows];

        for (UIWindow   *window in windows) {
                if (window.isKeyWindow) {
                    rootWindow = window;
                    break;
                }
            }
        rootViewController = rootWindow.rootViewController;
    }

    if (rootViewController == nil) {
        printf("Qualtrics: Unable to find the app's rootViewController\n");
        callback(@[@(false)]);
        return;
    }

    BOOL displayResult = [Qualtrics.shared displayWithViewController:rootViewController autoCloseSurvey:false];

    if (displayResult) {
        gTargetingResult = nil;
    }

    callback(@[@(displayResult)]);
}

RCT_EXPORT_METHOD(displayIntercept: (NSString *)interceptId callback: (RCTResponseSenderBlock)callback)
{
    UIViewController *rootViewController = [UIApplication sharedApplication].delegate.window.rootViewController;

    if (rootViewController == nil) {
        UIWindow *rootWindow = nil;
        NSArray *windows = [[UIApplication sharedApplication]windows];

        for (UIWindow   *window in windows) {
                if (window.isKeyWindow) {
                    rootWindow = window;
                    break;
                }
            }
        rootViewController = rootWindow.rootViewController;
    }

    if (rootViewController == nil) {
        printf("Qualtrics: Unable to find the app's rootViewController\n");
        callback(@[@(false)]);
        return;
    }

    BOOL displayResult = [Qualtrics.shared displayInterceptFor:interceptId viewController:rootViewController];
    callback(@[@(displayResult)]);
}

RCT_EXPORT_METHOD(registerViewVisit:(NSString* )viewName)
{
    [Qualtrics.shared registerViewVisitWithViewName:viewName];
}

RCT_EXPORT_METHOD(resetTimer) 
{
    [Qualtrics.shared resetTimer];
}

RCT_EXPORT_METHOD(resetViewCounter) 
{
    [Qualtrics.shared resetViewCounter];
}

RCT_EXPORT_METHOD(setString:(NSString* )key value:(NSString* )value)
{
    [Qualtrics.shared.properties setStringWithString:value for:key];
}

RCT_EXPORT_METHOD(setNumber:(NSString* )key value:(double)value)
{
    [Qualtrics.shared.properties setNumberWithNumber:value for:key];
}

RCT_EXPORT_METHOD(setDateTime:(NSString* )key)
{
    [Qualtrics.shared.properties setDateTimeFor:key];
}

RCT_EXPORT_METHOD(recordClick) 
{
    if (gTargetingResult != nil) {
        [gTargetingResult recordClick];
    }
}

RCT_EXPORT_METHOD(recordImpression) 
{
    if (gTargetingResult != nil) {
        [gTargetingResult recordImpression];
    }
}

RCT_EXPORT_METHOD(displayTarget:(RCTResponseSenderBlock)callback) 
{
    UIViewController *rootViewController = [UIApplication sharedApplication].delegate.window.rootViewController;
    BOOL displayTargetResult = false;

     if (rootViewController == nil) {
        UIWindow *rootWindow = nil;
        NSArray *windows = [[UIApplication sharedApplication]windows];

        for (UIWindow   *window in windows) {
                if (window.isKeyWindow) {
                    rootWindow = window;
                    break;
                }
            }
        rootViewController = rootWindow.rootViewController;
    }

    if (rootViewController == nil) {
        printf("Qualtrics: Unable to find the app's rootViewController\n");
        callback(@[@(false)]);
        return;
    }

    if (gTargetingResult != nil && gTargetingResult.getSurveyUrl != nil) {
        [Qualtrics.shared displayTargetWithTargetViewController:rootViewController targetUrl:gTargetingResult.getSurveyUrl autoCloseSurvey:false];
        displayTargetResult = true;
    }

    callback(@[@(displayTargetResult)]);
}

RCT_EXPORT_METHOD(setNotificationIconAsset:(NSString* ) asset)
{
    printf("iOS uses the App icon for all notifications, icon cannot be set.");
}

RCT_EXPORT_METHOD(getInitializedIntercepts:(RCTResponseSenderBlock)callback)
{
    NSArray *intercepts = Qualtrics.shared.getInitializedIntercepts;
    callback(@[intercepts]);
}

RCT_EXPORT_METHOD(getPassingIntercepts:(RCTResponseSenderBlock)callback)
{
    NSArray *intercepts = Qualtrics.shared.getPassingIntercepts;
    callback(@[intercepts]);
}

- (NSArray<NSString *> *)supportedEvents
{
  return @[INITIALIZE_EVENT, EVALUATE_EVENT, INITIALIZE_PROJECT_EVENT, EVALUATE_PROJECT_EVENT,
           EVALUATE_INTERCEPT_EVENT];
}

@end
