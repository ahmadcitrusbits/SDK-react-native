#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

#import <UIKit/UIApplication.h>
#import <UIKit/UIWindow.h>
@import Qualtrics;

@interface RNQualtricsDigital : RCTEventEmitter <RCTBridgeModule>

@end
